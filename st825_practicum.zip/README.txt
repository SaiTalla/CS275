README 

For the first problem, open the html file using chrome. Select a route number using the pull down option. After selecting a number, click on the button to display the table in the empty div.

For the second problem, open command prompt and go into the folder that has the problem 2 file. After that enter node st825_prob2.js in the command prompt. It will say server started. After that, type in the given URL in the web browser. It should say testingtestingtestingtestingtesting.