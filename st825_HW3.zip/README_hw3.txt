README 

To run this assignment, open the command prompt. Go to the folder where the html file and js file are stored. After that type in node st825_hw3.js in the command prompt.
There might be few errors where you might be missing some modules. Whatever module you are missing, type in "npm install *specified module*" to install it. 
The prompt should respond with "Server Started...".
Now go to google chrome and enter the URL: "localhost:8080".
This should output a webpage where the user can enter a number and choose to either calculate the factorial or summation of that number using the dropdown menu and given button.
The result will be displayed in the empty div. 